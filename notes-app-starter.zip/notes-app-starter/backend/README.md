
# FastAPI Backend (Notes API)

## Environment
- `PORT` (Render/Railway will set automatically)
- `DATABASE_URL` (optional, defaults to `sqlite:///./notes.db`)
- `FRONTEND_ORIGIN` (e.g., `https://your-vercel-domain.vercel.app` or `*` during testing)

## Run locally
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
# API at http://127.0.0.1:8000
```

## Deploy on Render
1. Create a new **Web Service** from this `backend/` folder.
2. Build Command: `pip install -r requirements.txt`
3. Start Command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
4. Set `FRONTEND_ORIGIN` to your Vercel URL after you deploy the frontend.
5. (Optional) Leave `DATABASE_URL` empty to use SQLite, or provide Postgres URL.

## Routes
- `GET /api/health`
- `GET /api/notes`
- `POST /api/notes` `{title?, content?}`
- `GET /api/notes/{id}`
- `PUT /api/notes/{id}` `{title?, content?, is_public?}`
- `DELETE /api/notes/{id}`
- `POST /api/notes/{id}/share`
- `POST /api/notes/{id}/unshare`
- `GET /api/public/{slug}`

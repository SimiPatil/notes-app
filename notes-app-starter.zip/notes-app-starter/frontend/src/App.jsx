
import React, { useEffect, useState } from 'react'
import { Routes, Route, Link, useNavigate, useParams } from 'react-router-dom'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000'

async function api(path, options={}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  })
  if (!res.ok) throw new Error(`API Error ${res.status}`)
  return res.status === 204 ? null : res.json()
}

function Layout({ children }) {
  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: 16, fontFamily: 'system-ui, sans-serif' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Link to="/" style={{ textDecoration: 'none' }}><h1>📝 Notes</h1></Link>
        <Link to="/new" className="btn">+ New</Link>
      </header>
      <hr />
      {children}
      <style>{`
        .btn { padding: 8px 12px; border: 1px solid #ccc; border-radius: 8px; text-decoration: none; }
        .note { border: 1px solid #e5e5e5; border-radius: 12px; padding: 12px; margin-bottom: 12px; }
        .row { display:flex; gap: 8px; align-items:center; flex-wrap: wrap; }
        textarea, input { width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 8px; }
        label { font-size: 12px; color: #666; }
        .muted { color: #666; font-size: 12px; }
        .danger { color: #b00; }
        .success { color: #0a0; }
      `}</style>
    </div>
  )
}

function ListPage() {
  const [notes, setNotes] = useState([])
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    api('/api/notes').then(setNotes).finally(() => setLoading(false))
  }, [])
  return (
    <Layout>
      {loading ? <p>Loading…</p> : (
        notes.length === 0 ? <p>No notes yet. Click <Link to="/new">New</Link> to create one.</p> :
        notes.map(n => (
          <div className="note" key={n.id}>
            <h3 style={{marginTop:0}}><Link to={`/edit/${n.id}`}>{n.title || 'Untitled'}</Link></h3>
            <p className="muted">{new Date(n.updated_at).toLocaleString()}</p>
            <div className="row">
              <Link className="btn" to={`/edit/${n.id}`}>Edit</Link>
              {n.is_public && n.slug ? (
                <a className="btn" href={`/s/${n.slug}`} target="_blank" rel="noreferrer">Open Share Link</a>
              ) : null}
            </div>
          </div>
        ))
      )}
    </Layout>
  )
}

function EditorPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const isNew = id === undefined
  const [note, setNote] = useState({ title: '', content: '', is_public: false, slug: null })
  const [info, setInfo] = useState(null)

  useEffect(() => {
    if (!isNew) {
      api(`/api/notes/${id}`).then(setNote).catch(() => navigate('/'))
    }
  }, [id, isNew, navigate])

  const save = async () => {
    if (isNew) {
      const created = await api('/api/notes', { method: 'POST', body: JSON.stringify({ title: note.title, content: note.content }) })
      navigate(`/edit/${created.id}`)
    } else {
      const updated = await api(`/api/notes/${id}`, { method: 'PUT', body: JSON.stringify({ title: note.title, content: note.content }) })
      setNote(updated)
      setInfo('Saved!')
      setTimeout(() => setInfo(null), 1500)
    }
  }

  const remove = async () => {
    if (confirm('Delete this note?')) {
      await api(`/api/notes/${id}`, { method: 'DELETE' })
      navigate('/')
    }
  }

  const share = async () => {
    const updated = await api(`/api/notes/${id}/share`, { method: 'POST' })
    setNote(updated)
    setInfo('Note is public now. Share link updated.')
    setTimeout(() => setInfo(null), 2000)
  }

  const unshare = async () => {
    const updated = await api(`/api/notes/${id}/unshare`, { method: 'POST' })
    setNote(updated)
    setInfo('Note is now private.')
    setTimeout(() => setInfo(null), 2000)
  }

  return (
    <Layout>
      <div className="note">
        <div className="row">
          <input
            placeholder="Title"
            value={note.title}
            onChange={e => setNote({ ...note, title: e.target.value })}
          />
        </div>
        <div className="row" style={{marginTop:8}}>
          <textarea
            placeholder="Write your note here…"
            rows={12}
            value={note.content}
            onChange={e => setNote({ ...note, content: e.target.value })}
          />
        </div>
        <div className="row" style={{marginTop:8}}>
          <button className="btn" onClick={save}>Save</button>
          {!isNew && (
            <>
              {!note.is_public ? (
                <button className="btn" onClick={share}>Share (make public)</button>
              ) : (
                <button className="btn" onClick={unshare}>Unshare (make private)</button>
              )}
              <button className="btn" onClick={remove}><span className="danger">Delete</span></button>
              {note.is_public && note.slug ? (
                <div>
                  <label>Public URL</label><br />
                  <a href={`/s/${note.slug}`} target="_blank" rel="noreferrer">{window.location.origin + `/s/${note.slug}`}</a>
                </div>
              ) : null}
            </>
          )}
        </div>
        {info && <p className="success">{info}</p>}
      </div>
    </Layout>
  )
}

function PublicNotePage() {
  const { slug } = useParams()
  const [note, setNote] = useState(null)
  const [error, setError] = useState(null)
  useEffect(() => {
    api(`/api/public/${slug}`)
      .then(setNote)
      .catch(() => setError('This note is not available.'))
  }, [slug])
  return (
    <Layout>
      {error ? <p className="danger">{error}</p> :
        note ? (
          <div className="note">
            <h2>{note.title}</h2>
            <pre style={{ whiteSpace: 'pre-wrap', fontFamily: 'inherit' }}>{note.content}</pre>
          </div>
        ) : <p>Loading…</p>}
    </Layout>
  )
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<ListPage />} />
      <Route path="/new" element={<EditorPage />} />
      <Route path="/edit/:id" element={<EditorPage />} />
      <Route path="/s/:slug" element={<PublicNotePage />} />
    </Routes>
  )
}

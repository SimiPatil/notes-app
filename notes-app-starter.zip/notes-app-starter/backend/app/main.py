
import os
import uuid
from datetime import datetime

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional

from sqlalchemy import create_engine, Column, Integer, String, Text, Boolean, DateTime, UniqueConstraint
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# --- Config ---
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./notes.db")
FRONTEND_ORIGIN = os.getenv("FRONTEND_ORIGIN", "*")
PORT = int(os.getenv("PORT", "10000"))

# --- DB Setup ---
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class Note(Base):
    __tablename__ = "notes"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), default="Untitled")
    content = Column(Text, default="")
    is_public = Column(Boolean, default=False)
    slug = Column(String(64), nullable=True, unique=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(bind=engine)

# --- Schemas ---
class NoteCreate(BaseModel):
    title: Optional[str] = "Untitled"
    content: Optional[str] = ""

class NoteUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    is_public: Optional[bool] = None

class NoteOut(BaseModel):
    id: int
    title: str
    content: str
    is_public: bool
    slug: Optional[str]
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

class PublicNoteOut(BaseModel):
    title: str
    content: str

# --- App ---
app = FastAPI(title="Notes API", version="1.0.0")

# CORS
origins = ["*"] if FRONTEND_ORIGIN == "*" else [FRONTEND_ORIGIN]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

from fastapi import Depends

# --- CRUD Routes ---
@app.get("/api/health")
def health():
    return {"status": "ok"}

@app.get("/api/notes", response_model=List[NoteOut])
def list_notes(db=Depends(get_db)):
    return db.query(Note).order_by(Note.updated_at.desc()).all()

@app.post("/api/notes", response_model=NoteOut, status_code=201)
def create_note(payload: NoteCreate, db=Depends(get_db)):
    now = datetime.utcnow()
    note = Note(title=payload.title or "Untitled", content=payload.content or "", created_at=now, updated_at=now)
    db.add(note)
    db.commit()
    db.refresh(note)
    return note

@app.get("/api/notes/{note_id}", response_model=NoteOut)
def get_note(note_id: int, db=Depends(get_db)):
    note = db.query(Note).filter(Note.id == note_id).first()
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")
    return note

@app.put("/api/notes/{note_id}", response_model=NoteOut)
def update_note(note_id: int, payload: NoteUpdate, db=Depends(get_db)):
    note = db.query(Note).filter(Note.id == note_id).first()
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")
    if payload.title is not None:
        note.title = payload.title
    if payload.content is not None:
        note.content = payload.content
    if payload.is_public is not None:
        note.is_public = payload.is_public
        if not payload.is_public:
            note.slug = None
    note.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(note)
    return note

@app.delete("/api/notes/{note_id}", status_code=204)
def delete_note(note_id: int, db=Depends(get_db)):
    note = db.query(Note).filter(Note.id == note_id).first()
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")
    db.delete(note)
    db.commit()
    return

# --- Share/Unshare ---
@app.post("/api/notes/{note_id}/share", response_model=NoteOut)
def share_note(note_id: int, db=Depends(get_db)):
    note = db.query(Note).filter(Note.id == note_id).first()
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")
    if not note.slug:
        note.slug = uuid.uuid4().hex[:12]
    note.is_public = True
    note.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(note)
    return note

@app.post("/api/notes/{note_id}/unshare", response_model=NoteOut)
def unshare_note(note_id: int, db=Depends(get_db)):
    note = db.query(Note).filter(Note.id == note_id).first()
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")
    note.is_public = False
    note.slug = None
    note.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(note)
    return note

# --- Public endpoint ---
@app.get("/api/public/{slug}", response_model=PublicNoteOut)
def get_public(slug: str, db=Depends(get_db)):
    note = db.query(Note).filter(Note.slug == slug, Note.is_public == True).first()
    if not note:
        raise HTTPException(status_code=404, detail="Public note not found")
    return PublicNoteOut(title=note.title, content=note.content)

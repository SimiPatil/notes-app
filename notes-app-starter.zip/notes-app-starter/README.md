
# Notes App (Full-Stack Template)

Live-ready template: React (Vite) on Vercel + FastAPI on Render/Railway.

## Quick Start

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload  # http://127.0.0.1:8000
```

### Frontend
```bash
cd frontend
npm install
npm run dev  # http://localhost:5173
```

Set `VITE_API_BASE` to your backend URL when deploying the frontend.

---

## Deploy Guide

### 1) FastAPI on Render
- New → Web Service → Connect repo or upload `backend/`
- Build command: `pip install -r requirements.txt`
- Start command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
- Env vars:
  - `FRONTEND_ORIGIN = https://<your-vercel-app>.vercel.app`
  - (optional) `DATABASE_URL` (leave blank to use SQLite)
- After deploy, note the URL, e.g. `https://notes-api-xyz.onrender.com`

### 2) React on Vercel
- New Project → Import `frontend/`
- Env var `VITE_API_BASE = https://notes-api-xyz.onrender.com`
- Deploy

### Test the Share Flow
1. Create a note → Save
2. Click **Share** → copy public URL → open in Incognito
3. Unshare to revoke

---

## API Summary
- `GET /api/health`
- `GET /api/notes`
- `POST /api/notes` `{title?, content?}`
- `GET /api/notes/{id}`
- `PUT /api/notes/{id}` `{title?, content?, is_public?}`
- `DELETE /api/notes/{id}`
- `POST /api/notes/{id}/share`
- `POST /api/notes/{id}/unshare`
- `GET /api/public/{slug}` → `{ title, content }`

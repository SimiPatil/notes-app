
# React Frontend (Vercel)

## Environment
- `VITE_API_BASE` — e.g., your Render/Railway backend URL, like `https://your-notes-api.onrender.com`

## Run locally
```bash
npm install
npm run dev
# Open http://localhost:5173
```

## Deploy to Vercel
1. Create a new Vercel project from this `frontend/` folder.
2. In **Settings → Environment Variables**, add `VITE_API_BASE = https://<your-backend-domain>`.
3. Deploy. That's it.

## Routes
- `/` — list notes
- `/new` — create a note
- `/edit/:id` — edit & share controls
- `/s/:slug` — public view
